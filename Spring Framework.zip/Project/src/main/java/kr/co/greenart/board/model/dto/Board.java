package kr.co.greenart.board.model.dto;

import kr.co.greenart.common.model.dto.ParentDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// Ctrl + Shift + O    ==> 자동 import
@Getter
@Setter
@ToString
public class Board extends ParentDto {
	
}
