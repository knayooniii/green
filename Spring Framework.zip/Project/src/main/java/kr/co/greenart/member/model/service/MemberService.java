package kr.co.greenart.member.model.service;

import kr.co.greenart.member.model.dto.Member;

public interface MemberService {
	Member loginMember(Member m);
	
	int checkEmail(String email);
	
	int registerMember(Member member);
}
