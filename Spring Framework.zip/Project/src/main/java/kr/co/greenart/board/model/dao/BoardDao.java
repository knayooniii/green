package kr.co.greenart.board.model.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.RowBounds;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import kr.co.greenart.board.model.dto.Board;
import kr.co.greenart.common.model.dto.PageInfo;

@Repository
public class BoardDao {

	public int selectListCount(SqlSessionTemplate sqlSession) {
		return sqlSession.selectOne("boardMapper.selectListCount");
	}
	
	public List<Board> selectListAll(SqlSessionTemplate sqlSession, PageInfo pi) {
		int offset = (pi.getCurrentPage()-1)*pi.getBoardLimit();
		
		RowBounds rowBounds = new RowBounds(offset, pi.getBoardLimit());
		
		return sqlSession.selectList("boardMapper.selectListAll", null, rowBounds);
	}

	public int insertBoard(SqlSessionTemplate sqlSession, Board board) {
		return sqlSession.insert("boardMapper.insertBoard", board);
	}
	
	public Board detailBoard(SqlSessionTemplate sqlSession, int idx) {
		return sqlSession.selectOne("boardMapper.detailBoard", idx);
	}
	
	public int countBoard(SqlSessionTemplate sqlSession, Board bo) {
		return sqlSession.update("boardMapper.countBoard", bo);
	}
	
	public int updateBoard(SqlSessionTemplate sqlSession, Board bo) {
		return sqlSession.update("boardMapper.updateBoard", bo);
	}

	public int deleteBoard(SqlSessionTemplate sqlSession, Board bo) {
		return sqlSession.delete("boardMapper.deleteBoard", bo);
	}

	public int uploadBoard(SqlSessionTemplate sqlSession, MultipartFile file) {
		return sqlSession.insert("boardMapper.uploadBoard", file);
	}

	public int searchListCount(SqlSessionTemplate sqlSession, String searchTxt) {
		return sqlSession.selectOne("boardMapper.searchListCount", searchTxt);
	}

	public List<Board> searchListAll(SqlSessionTemplate sqlSession, PageInfo pi, String searchTxt) {
		int offset = (pi.getCurrentPage()-1)*pi.getBoardLimit();
		
		RowBounds rowBounds = new RowBounds(offset, pi.getBoardLimit());
		
		return sqlSession.selectList("boardMapper.searchListAll", searchTxt ,rowBounds);
	}
}








