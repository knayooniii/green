package kr.co.greenart.board.controller;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import kr.co.greenart.board.model.dto.Board;
import kr.co.greenart.board.model.service.BoardServiceImpl;
import kr.co.greenart.common.controller.UploadFileController;
import kr.co.greenart.common.model.dto.PageInfo;
import kr.co.greenart.common.template.Pagination;

@Controller
@RequestMapping("/board") 
public class BoardController {
	private static final String UPLOAD_FOLDER = "C:\\Users\\GR803\\Documents\\workspace-sts-3.9.18.RELEASE\\Project\\src\\main\\webapp\\resources\\upload";

	@Autowired
	private BoardServiceImpl boardService;
	
	@Autowired
	private UploadFileController uploadFile;
	
	@GetMapping("/search.do")
	public String boardSearch(@RequestParam(value="searchTxt") String searchTxt,
							  @RequestParam(value="cpage", defaultValue="1") int currentPage,
							  Model model) {
				int listCount = boardService.searchListCount(searchTxt);                                                             
				int pageLimit = 10;
				int boardLimit = 15;
				int row = listCount - (currentPage-1) * boardLimit;
				
				PageInfo pi = Pagination.getPageInfo(listCount, currentPage, pageLimit, boardLimit);
				List<Board> list = boardService.searchListAll(pi, searchTxt);
				
				for(Board item : list) {
					item.setIndate(item.getIndate().substring(0, 10));
				}
				
				model.addAttribute("list", list); // 객체 바인딩
				model.addAttribute("pi", pi);
				model.addAttribute("row", row);
				
				return "board/boardList";
	}
	
	@GetMapping("/list.do")
	public String boardList(@RequestParam(value="cpage", defaultValue="1") int currentPage, 
							Model model,
							HttpSession session) {
		// 전체 게시글 수 구하기
		int listCount = boardService.selectListCount();                                                             
		
		// 보여질 페이지 수
		int pageLimit = 10;
		
		// 한 페이지에 보여질 게시글 수
		int boardLimit = 15;
		
		// 글 번호 뒤에서부터 출력해주는 변수
		int row = listCount - (currentPage-1) * boardLimit;
		
		// 페이징 로직 처리
		PageInfo pi = Pagination.getPageInfo(listCount, currentPage, pageLimit, boardLimit);
		
		// 목록 불러오기
		List<Board> list = boardService.selectListAll(pi);
		
		for(Board item : list) {
			item.setIndate(item.getIndate().substring(0, 10));
		}

		// 로그인 메시지
		String msg = (String) session.getAttribute("msg");
		String status = (String) session.getAttribute("status");
		
		model.addAttribute("list", list); // 객체 바인딩
		model.addAttribute("pi", pi);
		model.addAttribute("row", row);
		model.addAttribute("msg", msg);
		model.addAttribute("status", status);
		
		session.removeAttribute("msg");
		session.removeAttribute("status");
		
		return "board/boardList";
	}
	
	@GetMapping("enrollForm.do")
	public String enrollForm() {
		return "board/boardEnroll";
	}
	
	@PostMapping("insert.do")
	   public String insert(Board board, HttpSession session,
			   				MultipartFile upload) throws IllegalStateException, IOException {
	      // String name = (String session.getAttribute("memberName"))
	      // board.setWriter(name); 이걸 아래 한줄로 씀
		board.setWriter((String)session.getAttribute("memberName"));
		uploadFile.uploadFile(upload, board);

	      // result = 1 이 반환 되면 성공
	      // result = 0 이 반환 되면 실패
	      
	      int result = boardService.insertBoard(board);
	         if(result>0) {
	            return "redirect:/free/list.do";
	         }
	      return "common/errorPage";
	   }
	
	@GetMapping("detail.do")
	public String detailBoard(@RequestParam(value="boardIdx") int idx,
							  Model model,
							  HttpSession session) {
		Board result = boardService.detailBoard(idx);
		
		if(!Objects.isNull(result)) {
			int count = result.getCount()+1;
			result.setCount(count);
			result.setIdx(idx);
			boardService.countBoard(result);
			
			model.addAttribute("detail", result);
			model.addAttribute("user", session.getAttribute("memberName"));
			return "board/boardDetail";
		} else {
			// 원래는 에러페이지로 넘겨야함
			return "";
		}
	}
	
	@PostMapping("update.do")
	public String updateBoard(Board bo, HttpSession session) {
		int result = boardService.updateBoard(bo);
		
		if(result > 0) {
			session.setAttribute("msg", "수정 되었습니다.");
			session.setAttribute("status", "success");
			return "redirect:/board/list.do";
		} else {
			session.setAttribute("msg", "수정에 실패했습니다.");
			session.setAttribute("status", "error");
			return "redirect:/board/list.do";
		}
	}
	
	@PostMapping("delete.do")
	public String deleteBoard(Board bo, HttpSession session) {
		int result = boardService.deleteBoard(bo);
		
		if(result > 0) {
			session.setAttribute("msg", "삭제 되었습니다.");
			session.setAttribute("status", "success");
			return "redirect:/board/list.do";
		} else {
			session.setAttribute("msg", "삭제에 실패했습니다.");
			session.setAttribute("status", "error");
			return "redirect:/board/list.do";
		}
	}
	
	
}




























