package kr.co.greenart.notice.model.service;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.greenart.common.model.dto.PageInfo;
import kr.co.greenart.notice.model.dao.NoticeDao;
import kr.co.greenart.notice.model.dto.Notice;


@Service
public class NoticeServiceImpl implements NoticeService {

	@Autowired
	private NoticeDao noticeDao;
	
	@Autowired
	private SqlSessionTemplate sqlSession;
	
	@Override
	public int selectListCount() {
		return noticeDao.selectListCount(sqlSession);
	}
	
	@Override
	public List<Notice> selectListAll(PageInfo pi) {
		return noticeDao.selectListAll(sqlSession, pi);
	}
	
	
	
	
	
	
	
}
