package kr.co.greenart.common.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class SessionManageController {
	
	public String setSessionMessage(String msg, 
								  String status,
								  String path,
								  HttpSession session) {
		session.setAttribute("msg", msg);
		session.setAttribute("status", status);
		return "redirect:" + path;
	}
	
}
