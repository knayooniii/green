package kr.co.greenart.common.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.gson.Gson;

import kr.co.greenart.member.model.dto.JsonTest;

@Controller
public class IndexController {

	@RequestMapping("/")
	public String loginIndex() {
		// 자바 객체 생성
		JsonTest jsonTest = new JsonTest("김재섭", 21);
		
		// Gson 객체 생성
		Gson gson = new Gson();
		
		// JSON 생성
		// gson.toJson : 자바 객체 -> JSON 데이터 형식의 문자열로 변환
		System.out.println(jsonTest); // 자바 객체
		String jsonString = gson.toJson(jsonTest);
		System.out.println(jsonString); // 문자열 (JSON 데이터 형식)
		
		// JSON 파싱
		// JSON 데이터 형식의 문자열 -> 자바 객체
		JsonTest jsonParse = gson.fromJson(jsonString, JsonTest.class);
		
		System.out.println(jsonParse); // 자바 객체
		System.out.println(jsonParse.getName()); // DTO 객체이므로 getter, setter 사용 가능
		
		
		
		
		
		
		
		
		return "member/login";
	}
}
